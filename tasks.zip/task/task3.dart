
void main(){
  var list = [6, 8, 9, 4, 9];

  var sum ;

  print(sum = list.reduce((value, element) => value + element));
  
}