void main(){
  var fruits = [2,5,8,7,9,3];
  print(fruits.where((f) => f.isOdd).toList());
}

